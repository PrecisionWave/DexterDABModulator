/**
*
* @file dexter_dsp_tx_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define DEXTER_DSP_TX_STREAM_START1_MSB 0x90/**< stream_start1_msb */
#define DEXTER_DSP_TX_STREAM_START1_LSB 0x8c/**< stream_start1_lsb */
#define DEXTER_DSP_TX_STREAM_START0_MSB 0x50/**< stream_start0_msb */
#define DEXTER_DSP_TX_STREAM_START0_LSB 0x4c/**< stream_start0_lsb */
#define DEXTER_DSP_TX_RX_INC1 0x80/**< rx_inc1 */
#define DEXTER_DSP_TX_RX_INC0 0x40/**< rx_inc0 */
#define DEXTER_DSP_TX_PPS_SETTINGS 0x4/**< pps_settings */
#define DEXTER_DSP_TX_PPS_DELAY 0x10/**< pps_delay */
#define DEXTER_DSP_TX_GAIN_DC1 0x84/**< gain_dc1 */
#define DEXTER_DSP_TX_GAIN_DC0 0x44/**< gain_dc0 */
#define DEXTER_DSP_TX_BUFF_OVFLWS0 0x48/**< buff_ovflws0 */
#define DEXTER_DSP_TX_BUFF_OVFLWS1 0x88/**< buff_ovflws1 */
#define DEXTER_DSP_TX_CLKS_CNT_LSB 0x1c/**< clks_cnt_lsb */
#define DEXTER_DSP_TX_CLKS_CNT_MSB 0x20/**< clks_cnt_msb */
#define DEXTER_DSP_TX_NE_CLKS_CNT0_LSB 0x54/**< ne_clks_cnt0_lsb */
#define DEXTER_DSP_TX_NE_CLKS_CNT0_MSB 0x58/**< ne_clks_cnt0_msb */
#define DEXTER_DSP_TX_NE_CLKS_CNT1_LSB 0x94/**< ne_clks_cnt1_lsb */
#define DEXTER_DSP_TX_NE_CLKS_CNT1_MSB 0x98/**< ne_clks_cnt1_msb */
#define DEXTER_DSP_TX_PPS_CLKS_LSB 0x14/**< pps_clks_lsb */
#define DEXTER_DSP_TX_PPS_CLKS_MSB 0x18/**< pps_clks_msb */
#define DEXTER_DSP_TX_PPS_CNT 0xc/**< pps_cnt */
#define DEXTER_DSP_TX_PPS_ERROR 0x8/**< pps_error */
#define DEXTER_DSP_TX_VERSION 0x0/**< version */
